import PubSub from "pubsub-js";

export default class HandlerError {
  publicErro(erros) {
    erros.then(err => {
      console.log(err.errors);
      err.errors.forEach((erro, index) =>PubSub.publish("erro-validacao", erro));
    });
  }
}
