import React, { Component } from 'react'

export default class SelectCustom extends Component {

   render() {
       console.log(this.props);
    let autores = '';
    return (
     <div className="pure-control-group">
        <label htmlFor={this.props.id}>{this.props.label}</label>
        <select value={ this.state.autorId } name="autorId" onChange={ this.setAutorId }>
            <option value="">Selecione o autor</option>
            { 
                autores
              }
        </select>
      </div>
    )
  }
}
