import React, { Component } from "react";
import InputCustom from "./components/InputCustom";
import SubmitCustom from "./components/SubmitCustom";
import PubSub from "pubsub-js";
import HandlerError from "./HandlerError";

class FormularioAutor extends Component {
  constructor(props) {
    super(props);
    this.state = {
      nome: "",
      email: "",
      senha: ""
    };

    this.enviaForm = this.enviaForm.bind(this);
    
  }

  enviaForm(event) {
    event.preventDefault();

    fetch("http://cdc-react.herokuapp.com/api/autores", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        nome: this.state.nome,
        email: this.state.email,
        senha: this.state.senha
      })
    })
      .then(response => {
        if (response.ok) return response.json();
        else PubSub.publish("limpa-erros", {});
        throw new HandlerError().publicErro(response.json());
      })
      .then(data => {
        PubSub.publish("atualiza-lista", data);
        this.setState({ nome: "", email: "", senha: "" });
      })
      .catch(err => {
        console.error("Failed retrieving information", err);
      });
  }


  setInput(campo,event) {
    this.setState({[campo]: event.target.value });
  }



  render() {
    return (
      <div>
        <h2 className="content-subhead">Cadastro de Autores</h2>
        <form
          className="pure-form pure-form-aligned"
          onSubmit={this.enviaForm}
          method=""
        >
          <InputCustom
            label="Nome"
            id="nome"
            type="text"
            name="nome"
            value={this.state.nome}
            onChange={this.setInput.bind(this,'nome')}
          />

          <InputCustom
            label="Email"
            id="email"
            type="email"
            name="email"
            value={this.state.email}
            onChange={this.setInput.bind(this,'email')}
          />

          <InputCustom
            label="Senha"
            id="senha"
            type="password"
            name="senha"
            value={this.state.senha}
            onChange={this.setInput.bind(this,'senha')}
          />

          <SubmitCustom label="Gravar" />
        </form>
      </div>
    );
  }
}

class TabelaAutores extends Component {
  render() {
    return (
      <div>
        <table className="pure-table">
          <thead>
            <tr>
              <th>Nome</th>
              <th>Email</th>
            </tr>
          </thead>
          <tbody>
            {this.props.lista.map(autor => {
              return (
                <tr key={autor.id}>
                  <td>{autor.nome}</td>
                  <td>{autor.email}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    );
  }
}

export default class AutorBox extends Component {
  constructor(props) {
    super(props);
    this.state = { lista: [] };
  }

  componentDidMount() {
    fetch("http://cdc-react.herokuapp.com/api/autores")
      .then(response => {
        if (response.ok) return response.json();
        else throw new Error("Something went wrong");
      })
      .then(data => this.setState({ lista: data }))
      .catch(err => {
        console.error("Failed retrieving information", err);
      });

    PubSub.subscribe(
      "atualiza-lista",
      function(topic, novaLista) {
        this.setState({ lista: novaLista });
      }.bind(this)
    );
  }

  render() {
    return (
      <div>
        <div className="header">
          <h1>Cadastro de autores</h1>
        </div>
        <div className="content">
          <FormularioAutor />
          <TabelaAutores lista={this.state.lista} />
        </div>
      </div>
    );
  }
}
