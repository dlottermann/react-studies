import React, { Component } from "react";
import InputCustom from "./components/InputCustom";
import SubmitCustom from "./components/SubmitCustom";
import PubSub from "pubsub-js";
import HandlerError from "./HandlerError";
import SelectCustom from "./components/SelectCustom";

class LivroForm extends Component {
  constructor(props) {
    super(props);

    this.state = {
      titulo: '',
      preco: '',
      autorId:''
    };

    this.enviaForm = this.enviaForm.bind(this);
    this.setTitulo = this.setTitulo.bind(this);
    this.setPreco = this.setPreco.bind(this);
    this.setAutorId = this.setAutorId.bind(this);

  }

  setTitulo(event) {
     this.setState({ titulo: event.target.value });
  }

  setPreco(event) {
     this.setState({ preco: event.target.value });
  }

  setAutorId(event){
    this.setState({ autorId: event.target.value });
  }


  enviaForm(e) {
    e.preventDefault();

    fetch("http://cdc-react.herokuapp.com/api/livros", {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
            titulo: this.state.titulo,
            preco: this.state.preco,
            autorId: this.state.autorId
        })
      })
        .then(response => {
          if (response.ok) return response.json();
          else PubSub.publish("limpa-erros", {});
          throw new HandlerError().publicErro(response.json());
        })
        .then(data => {
          PubSub.publish("atualiza-lista-livros", data);
          this.setState({ titulo: '', preco: '', autorId: '' });
        })
        .catch(err => {
          console.error("Failed retrieving information", err);
        });


  }

  render() {
    return (
      <div>
        <h2 className="content-subhead">Cadastro de Livros</h2>
        <form
          className="pure-form pure-form-aligned"
          onSubmit={this.enviaForm}
          method=""
        >
          <InputCustom
            label="Titulo"
            id="titulo"
            type="text"
            name="titulo"
            value={this.state.titulo}
            onChange={this.setTitulo}
          />

          <InputCustom
            label="Preço"
            id="preco"
            type="text"
            name="preco"
            value={this.state.preco}
            onChange={this.setPreco}
          />
          <div className="pure-control-group">
          <label htmlFor="autorId">Autor</label>
          <select name="autorId" id="autorId" value={this.state.autorId} onChange={this.setAutorId}>
              <option value="">Selecione</option>
            {
              this.props.autores.map(autor=>{
                  return <option value={autor.id}>{autor.nome}</option>
              })
            }
          </select>
        </div>

          <SubmitCustom label="Gravar" />
        </form>
      </div>
    );
  }
}

class TabelaLivros extends Component {
  render() {
    return (
      <div>
        <table className="pure-table">
          <thead>
            <tr>
              <th>Titulo</th>
              <th>Preço</th>
              <th>Autor</th>
              <th>Email</th>
            </tr>
          </thead>
          <tbody>
            {this.props.lista.map(livro => {
              return (
                <tr key={livro.id}>
                  <td>{livro.titulo}</td>
                  <td>{livro.preco}</td>
                  <td>{livro.autor.nome}</td>
                  <td>{livro.autor.email}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    );
  }
}

export default class LivroBox extends Component {
  constructor() {
    super();
    this.state = { lista: [], listaAutores:[] };
  }

  componentDidMount() {
    fetch("http://cdc-react.herokuapp.com/api/livros")
      .then(response => {
        if (response.ok) return response.json();
        else throw new Error("Something went wrong");
      })
      .then(data => this.setState({ lista: data }))
      .catch(err => {
        console.error("Failed retrieving information", err);
      });

    PubSub.subscribe(
          "atualiza-lista-livros",
          function(topic, novaLista) {
            this.setState({ lista: novaLista });
          }.bind(this)
        );

    //fetch of authors    
    fetch("http://cdc-react.herokuapp.com/api/autores")
      .then(response => {
        if (response.ok) return response.json();
        else throw new Error("Something went wrong");
      })
      .then(data => this.setState({ listaAutores: data }))
      .catch(err => {
        console.error("Failed retrieving information", err);
      });


  }


  render() {
    return (
      <div>
        <div className="header">
          <h1>Cadastro de Livros</h1>
        </div>
        <div className="content">
          <LivroForm  autores={this.state.listaAutores}/>
          <TabelaLivros lista={this.state.lista} />
        </div>
      </div>
    );
  }
}
